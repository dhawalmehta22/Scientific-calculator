#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <dos.h>
#include <dir.h>

int main(int argc,char *argv[])
{
 SetColor(25);
 printf("\n \n \t This is dummy program for text color ");
 getch();

 return 0;
}
