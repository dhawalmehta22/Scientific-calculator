#include<stdio.h>
#include<conio.h>
 
main()
{
   textcolor(RED);
   cprintf("C programming");
 
   getch();
   return 0;
}

